//
//  QuanteecPluginBitmovin.h
//  QuanteecPluginBitmovin
//
//  Created by Attila Sütő on 02.07.2025.
//

#import <Foundation/Foundation.h>

//! Project version number for QuanteecPluginBitmovin.
FOUNDATION_EXPORT double QuanteecPluginBitmovinVersionNumber;

//! Project version string for QuanteecPluginBitmovin.
FOUNDATION_EXPORT const unsigned char QuanteecPluginBitmovinVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QuanteecPluginBitmovin/PublicHeader.h>


